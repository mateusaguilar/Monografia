data {
  int<lower=1> nteams;       // Número de times
  int<lower=1> ngames;       // Número total de jogos no treino
  int<lower=1> nrounds;      // Número total de rodadas
  int<lower=1,upper=nrounds> i_round[ngames];  // Rodada de cada jogo
  int<lower=1,upper=nteams> h[ngames];         // Índice do time da casa (home)
  int<lower=1,upper=nteams> a[ngames];         // Índice do time visitante (away)
  vector[ngames] x;           // Gols do time da casa (home goals)
  vector[ngames] y;           // Gols do time visitante (away goals)
  
  // Dados novos para previsão fora da amostra
  int<lower=0> ngames_new;   
  int<lower=1,upper=nrounds> i_round_new[ngames_new];
  int<lower=1,upper=nteams> h_new[ngames_new];
  int<lower=1,upper=nteams> a_new[ngames_new];
}

parameters {
  matrix[nrounds, nteams] att;   // habilidade ofensiva (attack) dinâmica
  matrix[nrounds, nteams] def;   // habilidade defensiva (defense) dinâmica

  real home;                     // efeito de jogar em casa
  real<lower=0> sigma_att;       // desvio padrão para variação ataque
  real<lower=0> sigma_def;       // desvio padrão para variação defesa
  real<lower=0> sigma_obs;       // desvio padrão observacional dos gols
}

model {
  // Priors
  to_vector(att[1]) ~ normal(0, 1);
  to_vector(def[1]) ~ normal(0, 1);
  
  home ~ normal(0, 1);
  sigma_att ~ cauchy(0, 2);
  sigma_def ~ cauchy(0, 2);
  sigma_obs ~ cauchy(0, 2);
  
  // Dinâmica dos parâmetros ataque e defesa ao longo das rodadas
  for (t in 2:nrounds) {
    for (team in 1:nteams) {
      att[t, team] ~ normal(att[t - 1, team], sigma_att);
      def[t, team] ~ normal(def[t - 1, team], sigma_def);
    }
  }
  
  // Likelihood dos gols observados (normal, com média dinâmica)
  for (k in 1:ngames) {
    real lambda = att[i_round[k], h[k]] + def[i_round[k], a[k]] + home;  // média gols casa
    real mu = att[i_round[k], a[k]] + def[i_round[k], h[k]];             // média gols visitante
    x[k] ~ normal(lambda, sigma_obs);
    y[k] ~ normal(mu, sigma_obs);
  }
}

generated quantities {
  vector[ngames] lambda;
  vector[ngames] mu;
  vector[ngames] x_pred;
  vector[ngames] y_pred;

  vector[ngames_new] lambda_new;
  vector[ngames_new] mu_new;
  vector[ngames_new] x_new;
  vector[ngames_new] y_new;

  // Calcula as médias para treino
  for (k in 1:ngames) {
    lambda[k] = att[i_round[k], h[k]] + def[i_round[k], a[k]] + home;
    mu[k] = att[i_round[k], a[k]] + def[i_round[k], h[k]];
  }

  // Amostras preditivas para dados de treino
  for (k in 1:ngames) {
    x_pred[k] = normal_rng(lambda[k], sigma_obs);
    y_pred[k] = normal_rng(mu[k], sigma_obs);
  }
  
  // Calcula médias para dados novos
  for (k in 1:ngames_new) {
    lambda_new[k] = att[i_round_new[k], h_new[k]] + def[i_round_new[k], a_new[k]] + home;
    mu_new[k] = att[i_round_new[k], a_new[k]] + def[i_round_new[k], h_new[k]];
  }

  // Amostras preditivas para dados novos
  for (k in 1:ngames_new) {
    x_new[k] = normal_rng(lambda_new[k], sigma_obs);
    y_new[k] = normal_rng(mu_new[k], sigma_obs);
  }
}
